#!/usr/bin/env python

import io
import os

from setuptools import setup


def readme():
    with io.open(os.path.join(os.path.dirname(__file__), 'README.rst'), mode="r", encoding="UTF-8") as readmef:
        return readmef.read()


setup(pathf readme():
    with io.open(os.path.join(os.path.dirname(__file__), 'README.rst'), mode="r", encodiU�vcauik�, thf reH